"""Pretend to be the ESP32: replay one child from the dataset into the API.

Simplest use (server must be running in another terminal):

  python simulate_device.py

It finds (or creates) the demo parent + child by itself, so there is NO key to copy,
sends the readings, and prints the summary and alerts at the end.

Options:
  python simulate_device.py --subject QU_C2 --speed 50 --limit 500
  python simulate_device.py --device-key <KEY>      (use a specific child's key)
"""
import argparse
import time
from pathlib import Path

import pandas as pd
import requests

CSV = Path(__file__).resolve().parent / "data" / "final_cleand_data.csv"
DEMO_EMAIL, DEMO_PASSWORD = "demo@calmband.com", "demo123"


def auto_device_key():
    """Find (or create) the demo parent and their newest child. Returns (key, child_id)."""
    from app import app
    import repositories as repo
    with app.app_context():
        user = (repo.get_user_by_email(DEMO_EMAIL)
                or repo.create_user("Demo Parent", DEMO_EMAIL, DEMO_PASSWORD))
        kids = repo.list_children(user.id)
        child = kids[-1] if kids else repo.create_child(user.id, "Demo Child")
        return child.device_key, child.id


def show_results(url, child_id):
    """Log in as the demo parent and print what the dashboard would show."""
    try:
        r = requests.post(f"{url}/api/auth/login", timeout=5,
                          json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD})
        h = {"Authorization": "Bearer " + r.json()["token"]}
        s = requests.get(f"{url}/api/children/{child_id}/summary", headers=h, timeout=5).json()
        alerts = requests.get(f"{url}/api/children/{child_id}/alerts", headers=h, timeout=5).json()
    except Exception as e:  # noqa: BLE001
        print("(could not read results:", e, ")")
        return
    print("\n================ RESULT ================")
    print(f"readings: {s['total_readings']}   calm: {s['calm_pct']}%   alerts: {s['alert_count']}")
    print(f"average HR: {s['avg_hr']}   baseline HR: {s['baseline_hr']}")
    for a in alerts[:8]:
        print(f"  alert #{a['id']}  {a['level']:<8}  {a['start_time']}  "
              f"{a['duration']} readings  peak HR {a['peak_hr']}  | {a['reason']}")
    if len(alerts) > 8:
        print(f"  ... and {len(alerts) - 8} more")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:5000")
    ap.add_argument("--device-key", default=None, help="optional: found automatically if omitted")
    ap.add_argument("--subject", default="QU_C2")
    ap.add_argument("--speed", type=float, default=50)
    ap.add_argument("--limit", type=int, default=0, help="stop after N readings (0 = all)")
    a = ap.parse_args()

    child_id = None
    key = a.device_key
    if key is None:
        key, child_id = auto_device_key()
        print(f"Using demo child #{child_id}  (key {key[:6]}...)")

    df = pd.read_csv(CSV)
    df = df[(df.subject_id == a.subject) & df.hr.notna()].sort_values("time_s")
    if df.empty:
        raise SystemExit(f"No rows for subject '{a.subject}' in {CSV.name}")
    if a.limit:
        df = df.head(a.limit)
    print(f"Sending {len(df)} readings of {a.subject} to {a.url} ...\n")

    headers = {"X-Device-Key": key}
    try:
        for i, r in enumerate(df.itertuples(), start=1):
            body = {"heart_rate": r.hr, "temperature": r.temp, "gsr": r.eda,
                    "x": r.x, "y": r.y, "z": r.z}
            resp = requests.post(f"{a.url}/api/device/data", json=body, headers=headers, timeout=5)
            if resp.status_code != 201:
                print("error:", resp.status_code, resp.text)
                return
            if i % 50 == 0:
                j = resp.json()
                print(f"{i:>5}  state={j['state']:<8} engine={j['engine']}")
            time.sleep(1 / a.speed)
    except requests.exceptions.ConnectionError:
        raise SystemExit("Cannot reach the server. Start it first:  flask --app app run --port 5000")

    if child_id is not None:
        show_results(a.url, child_id)


if __name__ == "__main__":
    main()
