"""SMOKE-TEST ONLY: writes a synthetic data/final_cleand_data.csv with the same columns
as the real dataset, so you can check the whole pipeline without the real file.
The model trained on this is meaningless. Do NOT use it for anything real.

  python tests/make_fake_csv.py [output_path]
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "data" / "final_cleand_data.csv"
rng = np.random.default_rng(0)
rows = []
for i in range(1, 6):
    n = 1200
    t = np.arange(n)
    label = np.zeros(n, int)
    for s in rng.choice(n - 40, 4, replace=False):
        label[s:s + 30] = 1
    hr = 90 + rng.normal(0, 2, n) + label * 20
    rows.append(pd.DataFrame({
        "source": "QU", "subject_id": f"QU_C{i}", "time_s": t, "hr": hr,
        "eda": 0.4 + rng.normal(0, .02, n) + label * .2, "temp": 33 + rng.normal(0, .05, n),
        "x": rng.normal(0, .1, n) + label * .3 * rng.normal(0, 1, n),
        "y": rng.normal(0, .1, n), "z": -1 + rng.normal(0, .1, n), "label": label}))
out.parent.mkdir(parents=True, exist_ok=True)
pd.concat(rows).to_csv(out, index=False)
print("wrote", out)
