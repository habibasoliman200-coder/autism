"""End-to-end API test.   python -m pytest tests -q   (or: python tests/test_api.py)"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")
os.environ["USE_AI"] = "0"          # test the rules path; AI needs a trained model

from app import create_app  # noqa: E402
from config import Config  # noqa: E402


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    USE_AI = False


def _client():
    return create_app(TestConfig).test_client()


def _register(c, email="a@x.com"):
    r = c.post("/api/auth/register", json={"name": "A", "email": email, "password": "secret1"})
    assert r.status_code == 201, r.get_json()
    return {"Authorization": "Bearer " + r.get_json()["token"]}


def test_full_flow():
    c = _client()
    h = _register(c)
    assert c.get("/api/auth/me", headers=h).get_json()["email"] == "a@x.com"
    assert c.post("/api/auth/login", json={"email": "a@x.com", "password": "bad"}).status_code == 401

    child = c.post("/api/children", json={"name": "Kid"}, headers=h).get_json()
    cid, key = child["id"], child["device_key"]
    assert c.get(f"/api/children/{cid}/current", headers=h).status_code == 404   # no readings yet

    dev = {"X-Device-Key": key}
    assert c.post("/api/device/data", json={"heart_rate": 90}, headers=dev).status_code == 400
    assert c.post("/api/device/data", json={"heart_rate": 90, "temperature": 33, "gsr": .4}).status_code == 401
    ids = []
    for i in range(60):                                   # calm baseline
        r = c.post("/api/device/data", headers=dev,
                   json={"heart_rate": 90, "temperature": 33, "gsr": .4, "x": 0, "y": 0, "z": -1})
        assert r.status_code == 201
        ids.append(r.get_json()["id"])
    for i in range(12):                                   # distress episode
        r = c.post("/api/device/data", headers=dev,
                   json={"heart_rate": 125, "temperature": 33, "gsr": .6, "motion": .9})
    assert r.get_json()["state"] == "distress"

    assert c.get(f"/api/children/{cid}/current", headers=h).get_json()["status"] == "distress"
    rd = c.get(f"/api/children/{cid}/readings?limit=20", headers=h).get_json()
    assert len(rd) == 20 and rd[0]["id"] < rd[-1]["id"]
    alerts = c.get(f"/api/children/{cid}/alerts", headers=h).get_json()
    assert alerts and alerts[0]["level"] == "distress"
    s = c.get(f"/api/children/{cid}/summary", headers=h).get_json()
    assert s["total_readings"] == 72 and s["alert_count"] >= 1

    fb = c.post(f"/api/children/{cid}/feedback", json={"reading_id": ids[0], "correct": False}, headers=h)
    assert fb.status_code == 201
    assert c.get(f"/api/children/{cid}/summary", headers=h).get_json()["feedback_false_alarm"] == 1

    # another parent must not see this child
    h2 = _register(c, "b@x.com")
    assert c.get(f"/api/children/{cid}/current", headers=h2).status_code == 404
    assert c.get("/api/children", headers=h2).get_json() == []
    assert c.get("/api/children").status_code == 401


def test_child_management_and_validation():
    c = _client()
    h = _register(c)
    child = c.post("/api/children", json={"name": "Kid"}, headers=h).get_json()
    cid, key = child["id"], child["device_key"]
    assert c.patch(f"/api/children/{cid}", json={"name": "Sam"}, headers=h).get_json()["name"] == "Sam"
    assert c.get(f"/api/children/{cid}", headers=h).get_json()["name"] == "Sam"

    ok = {"heart_rate": 90, "temperature": 33, "gsr": .4}
    assert c.post("/api/device/data", json=ok, headers={"X-Device-Key": key}).status_code == 201
    assert c.post("/api/device/data", json={**ok, "gsr": float("nan")},
                  headers={"X-Device-Key": key}).status_code == 400

    new = c.post(f"/api/children/{cid}/rotate-key", headers=h).get_json()["device_key"]
    assert new != key
    assert c.post("/api/device/data", json=ok, headers={"X-Device-Key": key}).status_code == 401
    assert c.post("/api/device/data", json=ok, headers={"X-Device-Key": new}).status_code == 201

    rid = c.get(f"/api/children/{cid}/current", headers=h).get_json()["id"]
    c.post(f"/api/children/{cid}/feedback", json={"reading_id": rid, "correct": True}, headers=h)
    assert c.delete(f"/api/children/{cid}", headers=h).status_code == 200
    assert c.get(f"/api/children/{cid}/current", headers=h).status_code == 404
    assert c.get("/api/children", headers=h).get_json() == []


if __name__ == "__main__":
    test_full_flow()
    test_child_management_and_validation()
    print("OK")
