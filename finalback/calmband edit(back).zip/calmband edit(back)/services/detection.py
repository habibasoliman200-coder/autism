"""Decision logic: AI model first, rule-based logic as the fallback.

decide() is the single entry point used by the device route.
"""
import math
import os

import joblib
import pandas as pd
from flask import current_app

import repositories as repo
from ml.features import BASELINE_WINDOW, FEATURE_COLUMNS, make_features

_model_bundle = None


def load_model(path):
    """Load model.joblib once. Returns None if the file does not exist."""
    global _model_bundle
    if _model_bundle is None and os.path.exists(path):
        _model_bundle = joblib.load(path)
    return _model_bundle


# ---------- rules (your original logic, unchanged in behaviour) ----------
def classify_rules(heart_rate, motion, baseline):
    cfg = current_app.config
    if not baseline or baseline <= 0:
        return "calm", 0
    ratio = heart_rate / baseline
    pct = round((ratio - 1) * 100)
    high_motion = motion >= cfg["MOTION_HIGH"]
    if ratio >= cfg["RATIO_DISTRESS"] and high_motion:
        return "distress", pct
    if ratio >= cfg["RATIO_EARLY"] or high_motion:
        return "early", pct
    return "calm", pct


# ---------- AI ----------
def ai_risk(child_id, new):
    """Probability (0..1) that this moment is a distress moment, or None if it can't be computed.

    `new` = dict with heart_rate, gsr, temperature, acc_x, acc_y, acc_z for the incoming reading.
    Needs accelerometer values and at least ~10 previous readings.
    """
    cfg = current_app.config
    if not cfg["USE_AI"]:
        return None
    bundle = load_model(cfg["MODEL_PATH"])
    if bundle is None or None in (new["acc_x"], new["acc_y"], new["acc_z"]):
        return None
    rows = list(reversed(repo.last_readings(child_id, BASELINE_WINDOW - 1)))
    if len(rows) < 10 or any(r.acc_x is None for r in rows):
        return None
    df = pd.DataFrame(
        [{"hr": r.heart_rate, "eda": r.gsr, "temp": r.temperature,
          "x": r.acc_x, "y": r.acc_y, "z": r.acc_z} for r in rows]
        + [{"hr": new["heart_rate"], "eda": new["gsr"], "temp": new["temperature"],
            "x": new["acc_x"], "y": new["acc_y"], "z": new["acc_z"]}])
    feats = make_features(df).iloc[[-1]][FEATURE_COLUMNS]
    if feats.isna().any(axis=None):
        return None
    return float(bundle["model"].predict_proba(feats)[:, 1][0])


def classify_ai(risk, threshold):
    cfg = current_app.config
    if risk >= threshold:
        return "distress"
    if risk >= threshold * cfg["AI_EARLY_RATIO"]:
        return "early"
    return "calm"


# ---------- smoothing ----------
def smooth(child_id, raw_status):
    """UI state changes only after N identical raw decisions in a row."""
    n = current_app.config["SMOOTHING"]
    prev = repo.last_readings(child_id, n - 1)
    if not prev:
        return "calm"
    if len(prev) == n - 1 and all(p.raw_status == raw_status for p in prev):
        return raw_status
    return prev[0].status


# ---------- main entry ----------
def decide(child_id, values):
    """values: heart_rate, temperature, gsr, motion, acc_x/y/z (may be None).
    Returns dict with raw_status, status, pct, risk, engine."""
    cfg = current_app.config
    baseline = repo.heart_rate_baseline(child_id, cfg["BASELINE_WINDOW"], cfg["MIN_BASELINE_READINGS"])
    rules_status, pct = classify_rules(values["heart_rate"], values["motion"], baseline)

    risk = ai_risk(child_id, values)
    if risk is not None and baseline:
        bundle = load_model(cfg["MODEL_PATH"])
        raw_status, engine = classify_ai(risk, bundle["threshold"]), "ai"
    else:
        raw_status, engine, risk = rules_status, "rules", None

    return {"raw_status": raw_status, "status": smooth(child_id, raw_status),
            "pct": pct, "risk": risk, "engine": engine}


# ---------- alert episodes ----------
def build_alerts(rows):
    """Group consecutive non-calm readings (oldest -> newest) into alert episodes."""
    cfg = current_app.config
    min_len, motion_high = cfg["MIN_ALERT_LENGTH"], cfg["MOTION_HIGH"]
    alerts, cur, count = [], None, 0
    for r in list(rows) + [None]:
        if r is not None and r.status != "calm":
            t = r.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            if cur is None:
                cur = {"child_id": r.child_id, "start_id": r.id, "start_time": t, "level": "early",
                       "peak_hr": r.heart_rate, "max_above_baseline_pct": r.above_baseline_pct,
                       "max_motion": r.motion, "max_risk": r.risk or 0.0}
                count = 0
            count += 1
            cur["end_id"], cur["end_time"], cur["duration"] = r.id, t, count
            if r.status == "distress":
                cur["level"] = "distress"
            cur["peak_hr"] = max(cur["peak_hr"], r.heart_rate)
            cur["max_above_baseline_pct"] = max(cur["max_above_baseline_pct"], r.above_baseline_pct)
            cur["max_motion"] = max(cur["max_motion"], r.motion)
            cur["max_risk"] = max(cur["max_risk"], r.risk or 0.0)
        elif cur is not None:
            if count >= min_len:
                alerts.append(cur)
            cur = None
    for i, a in enumerate(alerts, start=1):
        a["id"] = i
        a["peak_hr"] = round(a["peak_hr"], 1)
        a["max_risk"] = round(a["max_risk"], 3)
        reasons = []
        if a["max_above_baseline_pct"] >= 15:
            reasons.append(f"Heart rate up to {a['max_above_baseline_pct']}% above usual")
        if a["max_motion"] >= motion_high:
            reasons.append("High movement")
        a["reason"] = ", ".join(reasons) or "Unusual pattern"
    return alerts


def child_alerts(child_id, limit=3000):
    rows = repo.last_readings(child_id, limit)
    return build_alerts(reversed(rows))
