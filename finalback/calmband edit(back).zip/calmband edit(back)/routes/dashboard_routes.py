import csv
from pathlib import Path

from flask import Blueprint, current_app, g, jsonify, request

import repositories as repo
from auth import login_required, own_child_required
from services import detection

bp = Blueprint("dashboard", __name__, url_prefix="/api")

# ---------- demo live readings ----------
DEMO_LIVE = True  # خليه False لما الـ ESP32 الحقيقي يتوصل
_CSV = Path(__file__).resolve().parent.parent / "data" / "final_cleand_data.csv"
_demo_rows = None


def _load_demo_rows(subject="QU_C2"):
    global _demo_rows
    if _demo_rows is None:
        rows = []
        with open(_CSV, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                if r["subject_id"] == subject and r["hr"].strip().lower() not in ("", "nan"):
                    rows.append(r)
        rows.sort(key=lambda r: float(r["time_s"]))
        _demo_rows = rows
    return _demo_rows


def _add_demo_reading(child):
    """Store the next row of the dataset as a new reading (same path as receive_data)."""
    rows = _load_demo_rows()
    if not rows:
        return
    total, _, _ = repo.summary_counts(child.id)
    r = rows[total % len(rows)]  # next row after the last one, loops back to the start
    hr, temp, gsr = float(r["hr"]), float(r["temp"]), float(r["eda"])
    x, y, z = float(r["x"]), float(r["y"]), float(r["z"])
    motion = min(abs((x * x + y * y + z * z) ** 0.5 - 1.0) * 2, 1.0)
    values = {"heart_rate": hr, "temperature": temp, "gsr": gsr, "motion": motion,
              "acc_x": x, "acc_y": y, "acc_z": z}
    d = detection.decide(child.id, values)
    repo.add_reading(
        child_id=child.id, heart_rate=hr, temperature=temp, gsr=gsr, motion=motion,
        acc_x=x, acc_y=y, acc_z=z, above_baseline_pct=d["pct"], risk=d["risk"],
        raw_status=d["raw_status"], status=d["status"], engine=d["engine"],
        device_status="simulated")


def _baseline(child_id):
    cfg = current_app.config
    return repo.heart_rate_baseline(child_id, cfg["BASELINE_WINDOW"], cfg["MIN_BASELINE_READINGS"])


# ---------- children ----------
@bp.get("/children")
@login_required
def children():
    out = []
    for c in repo.list_children(g.user.id):
        base = _baseline(c.id)
        d = c.to_dict()
        d["baseline_hr"] = round(base, 1) if base else 0
        out.append(d)
    return jsonify(out)


@bp.post("/children")
@login_required
def add_child():
    name = (request.get_json(silent=True) or {}).get("name", "")
    if not name.strip():
        return jsonify({"status": "error", "message": "name is required"}), 400
    child = repo.create_child(g.user.id, name)
    # device_key is shown ONLY here: put it inside the ESP32 firmware
    return jsonify(child.to_dict(with_key=True)), 201


@bp.get("/children/<int:child_id>")
@login_required
@own_child_required
def get_child(child_id):
    return jsonify(g.child.to_dict())


@bp.patch("/children/<int:child_id>")
@login_required
@own_child_required
def rename_child(child_id):
    name = (request.get_json(silent=True) or {}).get("name", "")
    if not name.strip():
        return jsonify({"status": "error", "message": "name is required"}), 400
    return jsonify(repo.rename_child(g.child, name).to_dict())


@bp.post("/children/<int:child_id>/rotate-key")
@login_required
@own_child_required
def rotate_key(child_id):
    """Lost or leaked key? Get a new one (put it in the ESP32 firmware again)."""
    return jsonify(repo.rotate_device_key(g.child).to_dict(with_key=True))


@bp.delete("/children/<int:child_id>")
@login_required
@own_child_required
def delete_child(child_id):
    repo.delete_child(g.child)
    return jsonify({"deleted": True})


# ---------- live data for one child ----------
@bp.get("/children/<int:child_id>/current")
@login_required
@own_child_required
def current(child_id):
    if DEMO_LIVE:
        try:
            _add_demo_reading(g.child)
        except Exception:  # noqa: BLE001
            current_app.logger.exception("demo reading failed")
    row = repo.latest_reading(child_id)
    if row is None:
        return jsonify({"message": "No readings yet for this child"}), 404
    return jsonify(row.to_dict())


@bp.get("/children/<int:child_id>/readings")
@login_required
@own_child_required
def readings(child_id):
    """Last N readings, oldest -> newest (ready for a line chart)."""
    limit = min(request.args.get("limit", 300, type=int), 5000)
    rows = repo.last_readings(child_id, limit)
    return jsonify([r.to_dict() for r in reversed(rows)])


@bp.get("/children/<int:child_id>/alerts")
@login_required
@own_child_required
def alerts(child_id):
    return jsonify(detection.child_alerts(child_id))


@bp.get("/children/<int:child_id>/summary")
@login_required
@own_child_required
def summary(child_id):
    total, calm, avg_hr = repo.summary_counts(child_id)
    base = _baseline(child_id)
    ok, false_alarm = repo.feedback_counts(child_id)
    return jsonify({
        "child_id": child_id, "total_readings": total,
        "calm_pct": round(calm / total * 100) if total else 0,
        "alert_count": len(detection.child_alerts(child_id)),
        "avg_hr": round(avg_hr, 1), "baseline_hr": round(base, 1) if base else 0,
        "feedback_correct": ok, "feedback_false_alarm": false_alarm,
    })


# ---------- feedback ----------
@bp.post("/children/<int:child_id>/feedback")
@login_required
@own_child_required
def add_feedback(child_id):
    body = request.get_json(silent=True) or {}
    try:
        reading_id, correct = int(body["reading_id"]), bool(body["correct"])
    except (KeyError, TypeError, ValueError):
        return jsonify({"status": "error", "message": "need reading_id and correct"}), 400
    reading = repo.get_reading(reading_id)
    if reading is None or reading.child_id != child_id:
        return jsonify({"status": "error", "message": "reading not found for this child"}), 404
    repo.add_feedback(reading_id, child_id, g.user.id, correct)
    return jsonify({"saved": True}), 201


@bp.get("/children/<int:child_id>/feedback")
@login_required
@own_child_required
def list_feedback(child_id):
    return jsonify([{"id": f.id, "reading_id": f.reading_id, "correct": f.correct,
                     "time": f.timestamp.strftime("%Y-%m-%d %H:%M:%S")}
                    for f in repo.list_feedback(child_id)])