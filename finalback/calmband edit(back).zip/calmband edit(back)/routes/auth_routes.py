from flask import Blueprint, g, jsonify, request

import repositories as repo
from auth import login_required, make_token

bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@bp.post("/register")
def register():
    body = request.get_json(silent=True) or {}
    name, email, password = body.get("name", ""), body.get("email", ""), body.get("password", "")
    if not name.strip() or "@" not in email or len(password) < 6:
        return jsonify({"status": "error",
                        "message": "need name, a valid email and a password of 6+ characters"}), 400
    if repo.get_user_by_email(email):
        return jsonify({"status": "error", "message": "Email already registered"}), 409
    user = repo.create_user(name, email, password)
    return jsonify({"token": make_token(user), "user": user.to_dict()}), 201


@bp.post("/login")
def login():
    body = request.get_json(silent=True) or {}
    user = repo.get_user_by_email(body.get("email", ""))
    if user is None or not user.check_password(body.get("password", "")):
        return jsonify({"status": "error", "message": "Wrong email or password"}), 401
    return jsonify({"token": make_token(user), "user": user.to_dict()})


@bp.get("/me")
@login_required
def me():
    return jsonify(g.user.to_dict())
