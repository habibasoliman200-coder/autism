import math

from flask import Blueprint, g, jsonify, request

import repositories as repo
from auth import device_required
from services import detection

bp = Blueprint("device", __name__, url_prefix="/api/device")


def _num(content, key, default=None):
    v = content.get(key, default)
    if v is None:
        return None
    v = float(v)
    if not math.isfinite(v):
        raise ValueError(f"{key} is not a finite number")
    return v


@bp.post("/data")
@device_required
def receive_data():
    """Called by the ESP32 (or simulate_device.py) about once per second.

    Header : X-Device-Key: <child device key>
    Body   : {"heart_rate": 92, "temperature": 33.1, "gsr": 0.4,
              "x": -0.4, "y": -0.4, "z": -0.7,          <- accelerometer in g (needed by AI)
              "motion": 0.2,                             <- optional 0..1 (used by rules)
              "status": "text from device"}              <- optional
    """
    content = request.get_json(silent=True)
    if not content:
        return jsonify({"status": "error", "message": "No JSON data received"}), 400
    try:
        hr = _num(content, "heart_rate")
        temp = _num(content, "temperature")
        gsr = _num(content, "gsr")
        x, y, z = _num(content, "x"), _num(content, "y"), _num(content, "z")
        motion = _num(content, "motion")
    except (TypeError, ValueError):
        return jsonify({"status": "error", "message": "Sensor values must be numbers"}), 400
    if hr is None or temp is None or gsr is None:
        return jsonify({"status": "error", "message": "heart_rate, temperature and gsr are required"}), 400
    if not (20 <= hr <= 250):
        return jsonify({"status": "error", "message": "heart_rate out of range (20-250)"}), 400

    # if the device did not send "motion", derive it from the accelerometer (0..1)
    if motion is None:
        motion = min(abs(((x or 0) ** 2 + (y or 0) ** 2 + (z or 0) ** 2) ** 0.5 - 1.0) * 2, 1.0) \
            if x is not None else 0.0
    motion = min(max(motion, 0.0), 1.0)

    child = g.child
    values = {"heart_rate": hr, "temperature": temp, "gsr": gsr, "motion": motion,
              "acc_x": x, "acc_y": y, "acc_z": z}
    d = detection.decide(child.id, values)
    record = repo.add_reading(
        child_id=child.id, heart_rate=hr, temperature=temp, gsr=gsr, motion=motion,
        acc_x=x, acc_y=y, acc_z=z, above_baseline_pct=d["pct"], risk=d["risk"],
        raw_status=d["raw_status"], status=d["status"], engine=d["engine"],
        device_status=str(content.get("status", ""))[:200])
    return jsonify({"status": "success", "id": record.id, "state": d["status"],
                    "engine": d["engine"]}), 201
