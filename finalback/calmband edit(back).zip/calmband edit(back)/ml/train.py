"""Train the distress model.   python -m ml.train

- Uses only the QU subjects (the only ones with HR + label).
- Evaluation = leave-one-CHILD-out, so the score tells how the model behaves
  on a child it has never seen (the honest number).
"""
import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_auc_score

from ml.features import FEATURE_COLUMNS, make_features

ROOT = Path(__file__).resolve().parent.parent
CSV = ROOT / "data" / "final_cleand_data.csv"
OUT = ROOT / "ml" / "model.joblib"
REPORT = ROOT / "ml" / "report.json"


def load_training_frame():
    raw = pd.read_csv(CSV)
    raw = raw[(raw.source == "QU") & raw.hr.notna() & raw.label.notna()]
    parts = []
    for sid, g in raw.groupby("subject_id"):
        g = g.sort_values("time_s")
        f = make_features(g)
        f["label"] = g.label.values
        f["subject_id"] = sid
        parts.append(f)
    return pd.concat(parts, ignore_index=True).dropna().reset_index(drop=True)


def new_model():
    return HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, max_iter=300,
                                          class_weight="balanced", random_state=42)


def best_threshold(y, p, min_precision=0.30):
    prec, rec, thr = precision_recall_curve(y, p)
    ok = [(r, t) for pr, r, t in zip(prec[:-1], rec[:-1], thr) if pr >= min_precision]
    return float(max(ok)[1]) if ok else 0.5


def main():
    data = load_training_frame()
    print("rows:", len(data), "positives:", int(data.label.sum()))
    oof = pd.Series(index=data.index, dtype=float)
    per_child = {}
    for sid in data.subject_id.unique():
        tr, te = data[data.subject_id != sid], data[data.subject_id == sid]
        m = new_model().fit(tr[FEATURE_COLUMNS], tr.label)
        p = m.predict_proba(te[FEATURE_COLUMNS])[:, 1]
        oof.loc[te.index] = p
        per_child[sid] = {
            "pr_auc": round(float(average_precision_score(te.label, p)), 3),
            "roc_auc": round(float(roc_auc_score(te.label, p)), 3),
            "positive_rate": round(float(te.label.mean()), 3),
        }
    y = data.label.values
    thr = best_threshold(y, oof.values)
    pred = (oof.values >= thr).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    report = {
        "pr_auc": round(float(average_precision_score(y, oof)), 3),
        "roc_auc": round(float(roc_auc_score(y, oof)), 3),
        "baseline_pr_auc_random": round(float(y.mean()), 3),
        "threshold": round(thr, 3),
        "precision": round(tp / max(tp + fp, 1), 3),
        "recall": round(tp / max(tp + fn, 1), 3),
        "per_child_leave_one_out": per_child,
        "n_rows": int(len(data)), "n_positive": int(y.sum()),
    }
    print(json.dumps(report, indent=2))
    final = new_model().fit(data[FEATURE_COLUMNS], data.label)
    joblib.dump({"model": final, "threshold": thr, "features": FEATURE_COLUMNS}, OUT)
    REPORT.write_text(json.dumps(report, indent=2))
    print("saved", OUT)


if __name__ == "__main__":
    main()
