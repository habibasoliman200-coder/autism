"""Feature engineering shared by TRAINING and LIVE prediction.

Using one function for both guarantees the model sees the same kind of
numbers in the lab (CSV) and in production (readings coming from the ESP32).
Input: a DataFrame for ONE child, ordered oldest -> newest, 1 reading / second,
columns: hr, eda, temp, x, y, z.
"""
import numpy as np
import pandas as pd

WINDOW = 10            # seconds used for short-term statistics
BASELINE_WINDOW = 300  # same idea as the child's "usual" heart rate in the backend
MIN_BASELINE = 30

FEATURE_COLUMNS = [
    "hr", "hr_ratio", "hr_mean", "hr_std", "hr_slope",
    "eda", "eda_mean", "eda_std", "eda_slope",
    "temp", "temp_slope",
    "acc_std", "acc_jerk",
]


def _slope(s: pd.Series, w: int) -> pd.Series:
    return (s - s.shift(w - 1)) / (w - 1)


def make_features(df: pd.DataFrame) -> pd.DataFrame:
    d = df.reset_index(drop=True).copy()
    mag = np.sqrt(d.x ** 2 + d.y ** 2 + d.z ** 2)
    f = pd.DataFrame(index=d.index)
    base = d.hr.rolling(BASELINE_WINDOW, min_periods=MIN_BASELINE).median()
    f["hr"] = d.hr
    f["hr_ratio"] = d.hr / base
    f["hr_mean"] = d.hr.rolling(WINDOW, min_periods=WINDOW).mean()
    f["hr_std"] = d.hr.rolling(WINDOW, min_periods=WINDOW).std()
    f["hr_slope"] = _slope(d.hr, WINDOW)
    f["eda"] = d.eda
    f["eda_mean"] = d.eda.rolling(WINDOW, min_periods=WINDOW).mean()
    f["eda_std"] = d.eda.rolling(WINDOW, min_periods=WINDOW).std()
    f["eda_slope"] = _slope(d.eda, WINDOW)
    f["temp"] = d.temp
    f["temp_slope"] = _slope(d.temp, WINDOW)
    f["acc_std"] = mag.rolling(WINDOW, min_periods=WINDOW).std()
    f["acc_jerk"] = mag.diff().abs().rolling(WINDOW, min_periods=WINDOW).mean()
    return f[FEATURE_COLUMNS]
